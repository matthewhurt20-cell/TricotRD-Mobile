#!/bin/bash
# Run this once to bundle libraries for fully offline use
echo "Downloading libraries..."
curl -L "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" -o three.min.js
curl -L "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js" -o chart.umd.js
echo "Libraries downloaded. Edit TricotRD.html and replace CDN <script src=...> tags with:"
echo '  <script src="three.min.js"></script>'
echo '  <script src="chart.umd.js"></script>'
echo "Done!"
