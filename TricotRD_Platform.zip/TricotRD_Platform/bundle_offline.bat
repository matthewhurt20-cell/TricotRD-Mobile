@echo off
echo Downloading libraries for offline use...
powershell -Command "Invoke-WebRequest 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js' -OutFile 'three.min.js'"
powershell -Command "Invoke-WebRequest 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js' -OutFile 'chart.umd.js'"
echo Done! Libraries saved. Edit TricotRD.html to use local paths if needed.
pause
