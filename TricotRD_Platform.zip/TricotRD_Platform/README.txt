════════════════════════════════════════════════════════════
  TRICOT R&D PLATFORM — Warp Knitting Simulator
  Version 1.0
════════════════════════════════════════════════════════════

WHAT'S INCLUDED
───────────────
  TricotRD.html          — The full application (self-contained)
  launch_app.py          — Python launcher (best desktop experience)
  Launch_Windows.bat     — Double-click launcher for Windows
  Launch_Mac.command     — Double-click launcher for macOS
  Launch_Linux.sh        — Shell launcher for Linux
  bundle_offline.bat     — Downloads JS libs for fully offline use (Windows)
  bundle_offline.sh      — Downloads JS libs for fully offline use (Mac/Linux)
  README.txt             — This file


HOW TO RUN
──────────

  ► WINDOWS
    1. Double-click  Launch_Windows.bat
    — OR —
    Open TricotRD.html directly in Chrome or Edge

  ► macOS
    1. Right-click  Launch_Mac.command → Open
       (first time only; macOS asks permission for downloaded scripts)
    — OR —
    Open TricotRD.html in Chrome or Safari

  ► LINUX
    1. Run:  bash Launch_Linux.sh
    — OR —
    Open TricotRD.html in any browser

  ► BEST EXPERIENCE (all platforms)
    Install Python 3 (python.org) then run:
      python3 launch_app.py
    This opens the app in Chrome/Edge "app mode" — no browser chrome,
    no tabs, looks and feels like a native desktop application.


FEATURES
────────
  • Fabric 3D view          — Interactive yarn path rendering
  • Lapping diagram         — Point paper notation for all guide bars
  • Cross-section view      — Guide bar / needle bed geometry
  • Stress map              — Per-cell FEA-style tension heatmap
  • Risk analysis           — 6-parameter defect risk scoring + chart
  • Stitch library          — Save, load, and manage configurations
  • Compare                 — Side-by-side configuration comparison
  • 3D process simulation   — Real-time WebGL knitting cycle animation
  • AI analysis             — Claude AI integration (API key required)
  • PDF export              — Print-ready technical report


AI ANALYSIS SETUP
─────────────────
  The AI analysis tab uses the Anthropic Claude API.
  To enable it:
  1. Go to console.anthropic.com and create an account
  2. Generate an API key (sk-ant-...)
  3. Paste it into the "AI API key" field in the app's top bar
  Your key is never stored — enter it each session.


FULLY OFFLINE MODE
──────────────────
  The app loads Three.js and Chart.js from the internet by default.
  To run with NO internet connection at all:

  Windows:  double-click  bundle_offline.bat
  Mac/Linux: run          bash bundle_offline.sh

  Then open TricotRD.html, press Ctrl+U (view source), and replace:
    <script src="https://cdnjs.../three.min.js">
  with:
    <script src="three.min.js">
  (same for chart.umd.js)

  Note: AI analysis always requires internet.


SYSTEM REQUIREMENTS
───────────────────
  • Any modern browser: Chrome 80+, Edge 80+, Firefox 75+, Safari 14+
  • Python 3.6+ (optional, for app-mode launcher)
  • Internet: only needed for AI analysis and first-time JS library load
  • RAM: 256 MB minimum (512 MB recommended for 3D simulation)
  • WebGL support required for the 3D process simulation tab


SUPPORT
───────
  For questions about the simulation parameters, lapping movements,
  or fabric defect interpretation, use the built-in AI Analysis tab.

════════════════════════════════════════════════════════════
